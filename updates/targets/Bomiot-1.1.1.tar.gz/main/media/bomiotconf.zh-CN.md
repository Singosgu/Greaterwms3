# bomiotconf.ini

---

### 鉴定项目属性

- 这里控制该应用是bomiot的plugins还是project
- 如果是project，可以使用`bomiot market <project>`下载项目

```shell
[mode]
name = project
```