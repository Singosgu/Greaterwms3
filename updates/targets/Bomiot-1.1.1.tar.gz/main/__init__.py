def version():
    from main import __version__
    return __version__.version()
