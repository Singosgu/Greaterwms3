# Bomiot Application
print("Hello from Bomiot version 1.1.1")